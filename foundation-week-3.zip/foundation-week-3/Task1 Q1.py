answer=input("Is it raining outside? reply y/n")

if answer.lower()=='y': 
    print("Take an umbrella")
elif answer.lower()=='n':
    print("You don't need an umbrella")