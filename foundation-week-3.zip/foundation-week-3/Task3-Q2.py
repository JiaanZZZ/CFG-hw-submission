poem = 'I like Python and I am not very good at poems'
with open('poem.txt', 'w') as poem_file:
	poem_file.write(poem)